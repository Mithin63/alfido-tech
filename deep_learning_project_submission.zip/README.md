
# Deep Learning Mini Project

## Goal
Image classification using PyTorch and transfer learning (ResNet18 on CIFAR-10).

## Features
- Transfer Learning (Pretrained ResNet18)
- Data Augmentation
- Training Curve Plot
- Evaluation Metrics
- Saved Model (.pth)

## Run
pip install torch torchvision matplotlib scikit-learn

python train_classifier.py

## Outputs
- saved_model.pth
- training_curve.png
- classification report in terminal

## Inference
Load the saved model:

model.load_state_dict(torch.load("saved_model.pth"))
model.eval()
