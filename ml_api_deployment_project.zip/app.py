
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Iris Prediction API")

class IrisInput(BaseModel):
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float

@app.get("/")
def home():
    return {"message": "Model API Running"}

@app.post("/predict")
def predict(data: IrisInput):
    if data.petal_length < 2.5:
        prediction = "setosa"
    elif data.petal_width < 1.8:
        prediction = "versicolor"
    else:
        prediction = "virginica"

    return {"prediction": prediction}
