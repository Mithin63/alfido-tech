
# ML Model Deployment using FastAPI and Docker

## Run Locally

pip install -r requirements.txt

uvicorn app:app --reload

Open:
http://localhost:8000/docs

## Docker Build

docker build -t iris-api .

docker run -p 8000:8000 iris-api

## Example Request

POST /predict

{
  "sepal_length": 5.1,
  "sepal_width": 3.5,
  "petal_length": 1.4,
  "petal_width": 0.2
}

## Example Response

{
  "prediction": "setosa"
}

## GitHub Deliverables
- app.py
- Dockerfile
- requirements.txt
- README.md
